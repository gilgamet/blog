
<br/><form method="post">
    <?php echo $form->input('titre', 'Titre du Chapitre'); ?>
    <button class="btn btn-primary">Sauvegarder</button>

<br/><br/><br/><br/> 

</form>

