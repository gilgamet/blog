<?php

class CategoryTable extends Table
{

        protected $table = "categories";

}
    
